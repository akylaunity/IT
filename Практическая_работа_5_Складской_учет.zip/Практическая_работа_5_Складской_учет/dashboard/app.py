import os
import requests
import pandas as pd
import streamlit as st

API_URL = os.getenv('API_URL', 'http://127.0.0.1:8000')
st.set_page_config(page_title='Складской учёт', page_icon='📦', layout='wide')
st.title('📦 Складской учёт — аналитика')

if 'token' not in st.session_state:
    st.session_state.token = ''

with st.sidebar:
    st.header('Авторизация')
    username = st.text_input('Логин')
    password = st.text_input('Пароль', type='password')
    if st.button('Войти'):
        r = requests.post(f'{API_URL}/api/auth/login/', json={'username': username, 'password': password}, timeout=10)
        if r.ok:
            st.session_state.token = r.json()['access']
            st.success('Вход выполнен')
        else:
            st.error('Ошибка входа')

def api_get(path, params=None):
    headers = {'Authorization': f'Bearer {st.session_state.token}'} if st.session_state.token else {}
    r = requests.get(f'{API_URL}{path}', headers=headers, params=params, timeout=10)
    if r.status_code == 401:
        st.warning('Сначала войдите в систему слева.')
        return None
    r.raise_for_status()
    return r.json()

if st.session_state.token:
    days = st.slider('Период отчёта, дней', 7, 90, 30)
    kpi = api_get('/api/reports/kpi/', {'days': days})
    if kpi:
        c1, c2, c3, c4, c5 = st.columns(5)
        c1.metric('Поступлений', kpi['accepted_receipts'])
        c2.metric('Отгрузок', kpi['shipped_orders'])
        c3.metric('Мало остатков', kpi['low_stock_positions'])
        c4.metric('Товаров', kpi['active_products'])
        c5.metric('Стоимость запасов', f"{kpi['stock_value']:,.2f} ₽")

    st.subheader('Текущие остатки')
    stock = api_get('/api/reports/stock/')
    if stock is not None:
        st.dataframe(pd.DataFrame(stock), use_container_width=True)

    st.subheader('Товары ниже минимального остатка')
    low = api_get('/api/reports/low-stock/')
    if low is not None:
        df = pd.DataFrame(low)
        if df.empty:
            st.success('Все остатки в норме')
        else:
            st.dataframe(df, use_container_width=True)
