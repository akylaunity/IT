from django.contrib import admin
from .models import Category, Product, StockItem

@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    search_fields = ('name',)

@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ('name','sku','category','unit','purchase_price','selling_price','is_active')
    list_filter = ('category','is_active')
    search_fields = ('name','sku','barcode')

@admin.register(StockItem)
class StockItemAdmin(admin.ModelAdmin):
    list_display = ('product','quantity','location','updated_at')
    search_fields = ('product__name','product__sku','location')
