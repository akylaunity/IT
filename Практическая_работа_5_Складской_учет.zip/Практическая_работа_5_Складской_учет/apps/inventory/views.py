from rest_framework import viewsets
from .models import Category, Product, StockItem
from .serializers import CategorySerializer, ProductSerializer, StockItemSerializer

class CategoryViewSet(viewsets.ModelViewSet):
    queryset = Category.objects.all().order_by('name')
    serializer_class = CategorySerializer
    search_fields = ('name',)

class ProductViewSet(viewsets.ModelViewSet):
    queryset = Product.objects.select_related('category').all().order_by('name')
    serializer_class = ProductSerializer
    filterset_fields = ('category','is_active')
    search_fields = ('name','sku','barcode')
    ordering_fields = ('name','purchase_price','selling_price','created_at')

    def perform_create(self, serializer):
        product = serializer.save()
        StockItem.objects.get_or_create(product=product)

class StockViewSet(viewsets.ModelViewSet):
    queryset = StockItem.objects.select_related('product').all().order_by('product__name')
    serializer_class = StockItemSerializer
    search_fields = ('product__name','product__sku','location')
    ordering_fields = ('quantity','updated_at')
