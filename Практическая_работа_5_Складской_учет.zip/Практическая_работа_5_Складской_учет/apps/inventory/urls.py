from rest_framework.routers import DefaultRouter
from .views import CategoryViewSet, ProductViewSet, StockViewSet
router = DefaultRouter()
router.register('categories', CategoryViewSet, basename='categories')
router.register('products', ProductViewSet, basename='products')
router.register('stock', StockViewSet, basename='stock')
urlpatterns = router.urls
