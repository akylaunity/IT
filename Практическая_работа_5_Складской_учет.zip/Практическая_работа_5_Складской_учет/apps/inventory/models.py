from django.db import models

class Category(models.Model):
    name = models.CharField('Название', max_length=120, unique=True)
    def __str__(self): return self.name

class Product(models.Model):
    name = models.CharField('Наименование', max_length=180)
    sku = models.CharField('Артикул', max_length=50, unique=True)
    barcode = models.CharField('Штрихкод', max_length=64, unique=True, blank=True, null=True)
    category = models.ForeignKey(Category, on_delete=models.PROTECT, related_name='products')
    unit = models.CharField('Ед. измерения', max_length=20, default='шт.')
    purchase_price = models.DecimalField('Закупочная цена', max_digits=12, decimal_places=2, default=0)
    selling_price = models.DecimalField('Цена', max_digits=12, decimal_places=2, default=0)
    min_stock = models.DecimalField('Минимальный остаток', max_digits=12, decimal_places=3, default=0)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    def __str__(self): return f'{self.name} ({self.sku})'

class StockItem(models.Model):
    product = models.OneToOneField(Product, on_delete=models.CASCADE, related_name='stock')
    quantity = models.DecimalField('Остаток', max_digits=14, decimal_places=3, default=0)
    location = models.CharField('Ячейка / место хранения', max_length=80, blank=True)
    updated_at = models.DateTimeField(auto_now=True)
    @property
    def is_low(self): return self.quantity <= self.product.min_stock
    def __str__(self): return f'{self.product.name}: {self.quantity} {self.product.unit}'
