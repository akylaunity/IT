from rest_framework import serializers
from .models import Category, Product, StockItem

class CategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = Category
        fields = '__all__'

class ProductSerializer(serializers.ModelSerializer):
    category_name = serializers.CharField(source='category.name', read_only=True)
    quantity = serializers.DecimalField(source='stock.quantity', max_digits=14, decimal_places=3, read_only=True)
    location = serializers.CharField(source='stock.location', read_only=True)
    is_low = serializers.BooleanField(source='stock.is_low', read_only=True)
    class Meta:
        model = Product
        fields = ('id','name','sku','barcode','category','category_name','unit','purchase_price','selling_price','min_stock','is_active','quantity','location','is_low','created_at')
        read_only_fields = ('created_at',)

class StockItemSerializer(serializers.ModelSerializer):
    product_name = serializers.CharField(source='product.name', read_only=True)
    sku = serializers.CharField(source='product.sku', read_only=True)
    is_low = serializers.BooleanField(read_only=True)
    class Meta:
        model = StockItem
        fields = ('id','product','product_name','sku','quantity','location','is_low','updated_at')
