from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import User

@admin.register(User)
class WarehouseUserAdmin(UserAdmin):
    list_display = ('username', 'email', 'first_name', 'last_name', 'position', 'is_active')
    list_filter = ('position', 'is_active', 'is_staff')
    fieldsets = UserAdmin.fieldsets + (('Склад', {'fields': ('phone', 'position')}),)
