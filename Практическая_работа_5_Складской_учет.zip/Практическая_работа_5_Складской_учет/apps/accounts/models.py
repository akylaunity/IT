from django.contrib.auth.models import AbstractUser
from django.db import models

class User(AbstractUser):
    class Position(models.TextChoices):
        WAREHOUSEKEEPER = 'warehousekeeper', 'Кладовщик'
        MANAGER = 'manager', 'Менеджер склада'
        ADMIN = 'admin', 'Администратор'
        LOGISTIC = 'logistic', 'Поставщик / логист'
        ANALYST = 'analyst', 'Аналитик'

    email = models.EmailField('Email', unique=True)
    phone = models.CharField('Телефон', max_length=20, blank=True)
    position = models.CharField('Роль', max_length=20, choices=Position.choices, default=Position.WAREHOUSEKEEPER)

    def __str__(self):
        return f'{self.get_full_name() or self.username} — {self.get_position_display()}'
