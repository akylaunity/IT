from rest_framework.routers import DefaultRouter
from .views import SupplierViewSet, ReceiptViewSet, ReceiptItemViewSet
router = DefaultRouter()
router.register('suppliers', SupplierViewSet)
router.register('documents', ReceiptViewSet)
router.register('items', ReceiptItemViewSet)
urlpatterns = router.urls
