from decimal import Decimal
from django.conf import settings
from django.db import models, transaction
from django.utils import timezone
from apps.inventory.models import Product, StockItem

class Supplier(models.Model):
    name = models.CharField('Поставщик', max_length=160)
    phone = models.CharField('Телефон', max_length=30, blank=True)
    email = models.EmailField(blank=True)
    def __str__(self): return self.name

class Receipt(models.Model):
    class Status(models.TextChoices):
        DRAFT = 'draft', 'Черновик'
        ACCEPTED = 'accepted', 'Принято на склад'
        CANCELLED = 'cancelled', 'Отменено'
    number = models.CharField('Номер поступления', max_length=40, unique=True)
    supplier = models.ForeignKey(Supplier, on_delete=models.PROTECT, related_name='receipts')
    manager = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name='receipts')
    status = models.CharField(max_length=20, choices=Status.choices, default=Status.DRAFT)
    comment = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    accepted_at = models.DateTimeField(blank=True, null=True)

    @transaction.atomic
    def accept(self):
        if self.status == self.Status.ACCEPTED:
            return
        for item in self.items.select_related('product'):
            stock, _ = StockItem.objects.get_or_create(product=item.product)
            stock.quantity = (stock.quantity or Decimal('0')) + item.quantity
            stock.save(update_fields=['quantity','updated_at'])
        self.status = self.Status.ACCEPTED
        self.accepted_at = timezone.now()
        self.save(update_fields=['status','accepted_at'])

    def __str__(self): return self.number

class ReceiptItem(models.Model):
    receipt = models.ForeignKey(Receipt, on_delete=models.CASCADE, related_name='items')
    product = models.ForeignKey(Product, on_delete=models.PROTECT)
    quantity = models.DecimalField(max_digits=14, decimal_places=3)
    purchase_price = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    class Meta:
        unique_together = ('receipt','product')
