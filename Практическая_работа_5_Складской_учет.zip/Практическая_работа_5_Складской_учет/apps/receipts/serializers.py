from rest_framework import serializers
from .models import Supplier, Receipt, ReceiptItem

class SupplierSerializer(serializers.ModelSerializer):
    class Meta:
        model = Supplier
        fields = '__all__'

class ReceiptItemSerializer(serializers.ModelSerializer):
    product_name = serializers.CharField(source='product.name', read_only=True)
    class Meta:
        model = ReceiptItem
        fields = ('id','product','product_name','quantity','purchase_price')

class ReceiptSerializer(serializers.ModelSerializer):
    items = ReceiptItemSerializer(many=True, read_only=True)
    supplier_name = serializers.CharField(source='supplier.name', read_only=True)
    manager_name = serializers.CharField(source='manager.get_full_name', read_only=True)
    class Meta:
        model = Receipt
        fields = ('id','number','supplier','supplier_name','manager','manager_name','status','comment','created_at','accepted_at','items')
        read_only_fields = ('manager','status','created_at','accepted_at')
