from django.contrib import admin
from .models import Supplier, Receipt, ReceiptItem

class ReceiptItemInline(admin.TabularInline):
    model = ReceiptItem
    extra = 1

@admin.register(Supplier)
class SupplierAdmin(admin.ModelAdmin):
    list_display = ('name','phone','email')
    search_fields = ('name','phone','email')

@admin.register(Receipt)
class ReceiptAdmin(admin.ModelAdmin):
    list_display = ('number','supplier','manager','status','created_at','accepted_at')
    list_filter = ('status','supplier')
    search_fields = ('number','supplier__name')
    inlines = [ReceiptItemInline]
