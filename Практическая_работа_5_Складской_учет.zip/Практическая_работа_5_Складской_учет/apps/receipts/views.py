from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from .models import Supplier, Receipt, ReceiptItem
from .serializers import SupplierSerializer, ReceiptSerializer, ReceiptItemSerializer

class SupplierViewSet(viewsets.ModelViewSet):
    queryset = Supplier.objects.all().order_by('name')
    serializer_class = SupplierSerializer
    search_fields = ('name','phone','email')

class ReceiptViewSet(viewsets.ModelViewSet):
    queryset = Receipt.objects.select_related('supplier','manager').prefetch_related('items__product').all().order_by('-created_at')
    serializer_class = ReceiptSerializer
    filterset_fields = ('status','supplier')
    search_fields = ('number','supplier__name')

    def perform_create(self, serializer):
        serializer.save(manager=self.request.user)

    @action(detail=True, methods=['post'])
    def accept(self, request, pk=None):
        receipt = self.get_object()
        receipt.accept()
        return Response(self.get_serializer(receipt).data)

class ReceiptItemViewSet(viewsets.ModelViewSet):
    queryset = ReceiptItem.objects.select_related('receipt','product').all()
    serializer_class = ReceiptItemSerializer
    filterset_fields = ('receipt','product')
