from django.contrib import admin
from .models import Shipment, ShipmentItem

class ShipmentItemInline(admin.TabularInline):
    model = ShipmentItem
    extra = 1

@admin.register(Shipment)
class ShipmentAdmin(admin.ModelAdmin):
    list_display = ('number','customer','manager','status','created_at','shipped_at')
    list_filter = ('status','created_at')
    search_fields = ('number','customer','address')
    inlines = [ShipmentItemInline]
