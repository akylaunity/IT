from rest_framework.routers import DefaultRouter
from .views import ShipmentViewSet, ShipmentItemViewSet
router = DefaultRouter()
router.register('shipments', ShipmentViewSet)
router.register('items', ShipmentItemViewSet)
urlpatterns = router.urls
