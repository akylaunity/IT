from rest_framework import serializers
from .models import Shipment, ShipmentItem

class ShipmentItemSerializer(serializers.ModelSerializer):
    product_name = serializers.CharField(source='product.name', read_only=True)
    class Meta:
        model = ShipmentItem
        fields = ('id','product','product_name','quantity')

class ShipmentSerializer(serializers.ModelSerializer):
    items = ShipmentItemSerializer(many=True, read_only=True)
    manager_name = serializers.CharField(source='manager.get_full_name', read_only=True)
    class Meta:
        model = Shipment
        fields = ('id','number','customer','address','manager','manager_name','status','comment','created_at','shipped_at','items')
        read_only_fields = ('manager','created_at','shipped_at')
