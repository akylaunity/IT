from django.core.exceptions import ValidationError
from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from .models import Shipment, ShipmentItem
from .serializers import ShipmentSerializer, ShipmentItemSerializer

class ShipmentViewSet(viewsets.ModelViewSet):
    queryset = Shipment.objects.select_related('manager').prefetch_related('items__product').all().order_by('-created_at')
    serializer_class = ShipmentSerializer
    filterset_fields = ('status',)
    search_fields = ('number','customer','address')

    def perform_create(self, serializer):
        serializer.save(manager=self.request.user)

    @action(detail=True, methods=['post'])
    def ship(self, request, pk=None):
        shipment = self.get_object()
        try:
            shipment.ship()
        except ValidationError as exc:
            return Response({'detail': exc.message}, status=status.HTTP_400_BAD_REQUEST)
        return Response(self.get_serializer(shipment).data)

class ShipmentItemViewSet(viewsets.ModelViewSet):
    queryset = ShipmentItem.objects.select_related('shipment','product').all()
    serializer_class = ShipmentItemSerializer
    filterset_fields = ('shipment','product')
