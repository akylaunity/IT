from decimal import Decimal
from django.conf import settings
from django.core.exceptions import ValidationError
from django.db import models, transaction
from django.utils import timezone
from apps.inventory.models import Product, StockItem

class Shipment(models.Model):
    class Status(models.TextChoices):
        NEW = 'new', 'Новый'
        PICKING = 'picking', 'Комплектуется'
        READY = 'ready', 'Готов к отгрузке'
        SHIPPED = 'shipped', 'Отгружен'
        CANCELLED = 'cancelled', 'Отменён'
    number = models.CharField('Номер заказа', max_length=40, unique=True)
    customer = models.CharField('Получатель', max_length=160)
    address = models.CharField('Адрес', max_length=255, blank=True)
    manager = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name='shipments')
    status = models.CharField(max_length=20, choices=Status.choices, default=Status.NEW)
    comment = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    shipped_at = models.DateTimeField(blank=True, null=True)

    @transaction.atomic
    def ship(self):
        if self.status == self.Status.SHIPPED:
            return
        for item in self.items.select_related('product'):
            stock, _ = StockItem.objects.select_for_update().get_or_create(product=item.product)
            if stock.quantity < item.quantity:
                raise ValidationError(f'Недостаточно товара: {item.product.name}')
            stock.quantity = (stock.quantity or Decimal('0')) - item.quantity
            stock.save(update_fields=['quantity','updated_at'])
        self.status = self.Status.SHIPPED
        self.shipped_at = timezone.now()
        self.save(update_fields=['status','shipped_at'])

    def __str__(self): return self.number

class ShipmentItem(models.Model):
    shipment = models.ForeignKey(Shipment, on_delete=models.CASCADE, related_name='items')
    product = models.ForeignKey(Product, on_delete=models.PROTECT)
    quantity = models.DecimalField(max_digits=14, decimal_places=3)
    class Meta:
        unique_together = ('shipment','product')
