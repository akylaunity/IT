from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from apps.inventory.models import Product
from apps.inventory.serializers import ProductSerializer

class BarcodeLookupView(APIView):
    def get(self, request, code):
        try:
            product = Product.objects.select_related('category').get(barcode=code)
        except Product.DoesNotExist:
            return Response({'detail': 'Товар с таким штрихкодом не найден'}, status=status.HTTP_404_NOT_FOUND)
        return Response(ProductSerializer(product).data)
