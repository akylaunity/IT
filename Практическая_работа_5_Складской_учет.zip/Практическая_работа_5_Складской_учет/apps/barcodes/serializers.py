# Сериализатор берётся из apps.inventory.serializers.ProductSerializer.
