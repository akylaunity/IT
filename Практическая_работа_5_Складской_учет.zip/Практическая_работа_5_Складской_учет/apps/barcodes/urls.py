from django.urls import path
from .views import BarcodeLookupView
urlpatterns = [path('lookup/<str:code>/', BarcodeLookupView.as_view(), name='barcode_lookup')]
