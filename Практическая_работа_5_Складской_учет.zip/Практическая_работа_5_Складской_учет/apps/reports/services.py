from datetime import timedelta
from django.db.models import Sum, F, DecimalField, ExpressionWrapper
from django.utils import timezone
from apps.inventory.models import Product, StockItem
from apps.receipts.models import Receipt, ReceiptItem
from apps.orders.models import Shipment, ShipmentItem

class ReportService:
    @staticmethod
    def kpi(days=30):
        since = timezone.now() - timedelta(days=days)
        accepted = Receipt.objects.filter(status=Receipt.Status.ACCEPTED, accepted_at__gte=since).count()
        shipped = Shipment.objects.filter(status=Shipment.Status.SHIPPED, shipped_at__gte=since).count()
        low_stock = StockItem.objects.filter(quantity__lte=F('product__min_stock')).count()
        total_products = Product.objects.filter(is_active=True).count()
        stock_value = StockItem.objects.aggregate(
            total=Sum(ExpressionWrapper(F('quantity') * F('product__purchase_price'), output_field=DecimalField(max_digits=18, decimal_places=2)))
        )['total'] or 0
        return {
            'days': days,
            'accepted_receipts': accepted,
            'shipped_orders': shipped,
            'low_stock_positions': low_stock,
            'active_products': total_products,
            'stock_value': float(stock_value),
        }

    @staticmethod
    def low_stock():
        rows = StockItem.objects.select_related('product').filter(quantity__lte=F('product__min_stock')).order_by('quantity')
        return [
            {'sku': x.product.sku, 'product': x.product.name, 'quantity': float(x.quantity), 'min_stock': float(x.product.min_stock), 'location': x.location}
            for x in rows
        ]

    @staticmethod
    def stock():
        rows = StockItem.objects.select_related('product').order_by('product__name')
        return [
            {'sku': x.product.sku, 'product': x.product.name, 'quantity': float(x.quantity), 'unit': x.product.unit, 'location': x.location}
            for x in rows
        ]
