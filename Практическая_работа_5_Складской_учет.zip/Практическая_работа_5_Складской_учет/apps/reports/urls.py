from django.urls import path
from .views import KPIView, LowStockView, StockReportView
urlpatterns = [
    path('kpi/', KPIView.as_view(), name='kpi'),
    path('low-stock/', LowStockView.as_view(), name='low_stock'),
    path('stock/', StockReportView.as_view(), name='stock_report'),
]
