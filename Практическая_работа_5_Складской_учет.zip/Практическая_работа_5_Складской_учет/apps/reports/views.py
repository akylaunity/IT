from rest_framework.views import APIView
from rest_framework.response import Response
from .services import ReportService

class KPIView(APIView):
    def get(self, request):
        return Response(ReportService.kpi(int(request.GET.get('days', 30))))

class LowStockView(APIView):
    def get(self, request):
        return Response(ReportService.low_stock())

class StockReportView(APIView):
    def get(self, request):
        return Response(ReportService.stock())
